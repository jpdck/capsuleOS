### [Google Chrome](https://www.google.com/chrome)

#### Activating theme

1. Type `chrome://extensions` in the address bar;
2. Select the "Developer mode" checkbox;
3. Click the "Load unpacked" button;
4. Choose the "dracula-pro" directory.
