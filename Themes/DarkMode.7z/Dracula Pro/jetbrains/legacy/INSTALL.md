### [JetBrains IDE](https://www.jetbrains.com/)

#### Installation

1. Go to `Preferences -> Plugins`
2. Click the Gear icon at the top right
3. Select `Install Plugin from Disk...`
4. Choose the ZIP file
5. Click on `Apply` button, then restart IDE

#### Activate theme

1. Open `Preferences -> Appearance & Behavior -> Appearance`
2. Select one of the Dracula Pro variations