### [JetBrains Fleet](https://jetbrains.com/fleet)

#### Installation

1. Copy the `.json` files to `~/.fleet/themes/`
2. Select one of the Dracula Pro variations within Fleet
