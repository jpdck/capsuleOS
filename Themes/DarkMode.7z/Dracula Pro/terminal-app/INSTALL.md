### [Terminal.app](https://en.wikipedia.org/wiki/Terminal_(macOS))

#### Activating theme

1.  _Terminal > Profiles Tab_
2.  Click _"Gear" icon_
3.  Click _Import..._
4.  Select the `Dracula Pro.terminal` file
5.  Click _Default_
