### [Zed](https://zed.dev/)

#### Installation

1. Copy the `dracula_pro.json` file to `~/.config/zed/themes`;
2. Select one of the Dracula Pro variations;
3. Boom! It's working ✨
