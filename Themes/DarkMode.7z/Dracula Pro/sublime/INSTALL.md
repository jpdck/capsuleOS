### [Sublime Text](https://www.sublimetext.com)

#### Install

1. Find your `Packages` directory using the menu item `Preferences -> Browse Packages...`
2. Copy the `sublime` folder into your Sublime Text `Packages` directory
3. Rename the folder to `Dracula Pro`

#### Activating theme

1. Go to `Preferences -> Select Theme...` and select the `Adaptive`.
2. Go to `Preferences -> Select Color Scheme...` and select the `Dracula Pro` color scheme of your choice.
