### [Notepad++](https://notepad-plus-plus.org/)

#### Activating theme

1.  Go to `%AppData%\Notepad++\themes`
2.  Place `Dracula PRO.xml` inside that folder
3.  Restart Notepad++
4.  Dracula PRO will be available in `Settings > Style Configurator`

> Note: (%AppData% is platform dependent environment variable. Open a Command Prompt and execute `echo %AppData%`)

#### Known Limitations

Notepad++ does not offer syntax highlighting for Markdown files yet.