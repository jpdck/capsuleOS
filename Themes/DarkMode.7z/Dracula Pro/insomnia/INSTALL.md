### [Insomnia](http://insomnia.rest)

#### Install

1. Copy the folder named `dracula-pro`;
2. Start Insomnia;
3. Go to `Application > Preferences`;
4. Click on the `Plugins` tab;
5. Click on the `Reveal Plugins Folder` button;
6. Paste the `dracula-pro` folder into the revealed location.

#### Activating theme

1. Go to `Application > Preferences`;
2. Click on the `Plugins` tab;
3. Ensure the `insomnia-plugin-theme-dracula-pro` plugin is enabled;
4. Click on the `Themes` tab;
5. Select `Dracula PRO` to apply the theme. 😊
