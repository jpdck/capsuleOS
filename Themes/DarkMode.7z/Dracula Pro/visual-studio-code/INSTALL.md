### [Visual Studio Code](https://code.visualstudio.com/)

#### Activating theme

1. Go to `View -> Command Palette` or press `Ctrl+Shift+P`
2. Type `Extensions: Install from VSIX...`
3. Find the `dracula-pro.vsix` file
4. Then select Dracula Pro from `Preferences -> Color Theme` dropdown menu.
